-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 12, 2015 at 04:40 PM
-- Server version: 5.5.42-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `currentc_extrabux`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE IF NOT EXISTS `applicants` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `health` varchar(100) NOT NULL,
  `damage` int(4) NOT NULL,
  `attacks` int(4) NOT NULL,
  `dodge` int(4) NOT NULL,
  `critical` int(4) NOT NULL,
  `initiative` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`id`, `name`, `health`, `damage`, `attacks`, `dodge`, `critical`, `initiative`) VALUES
(1, 'Tom Cruise', '136', 6, 4, 10, 10, 4),
(2, 'Sponge Bob', '110', 4, 5, 12, 12, 5),
(3, 'James Earl Jonese', '175', 8, 3, 20, 8, 3),
(4, 'Bob Barkerb', '112', 2, 8, 4, 62, 2),
(5, 'Tonya Harding', '108', 7, 4, 12, 18, 4),
(6, 'Charles Barkley', '220', 12, 2, 4, 10, 2),
(7, 'Peter Piper', '116', 4, 6, 14, 14, 6),
(8, 'Harry Potter', '96', 16, 2, 16, 15, 6),
(9, 'Shamu', '280', 24, 1, 0, 0, 0),
(10, 'Bill Gates', '124', 6, 4, 8, 12, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
